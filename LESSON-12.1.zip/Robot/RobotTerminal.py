from os import system, name
import RobotClass as robot

def clear():
	_ = system('cls')

# VARIABLES
robot = robot.Robot()
continueProgram = True

# BODY
clear()
print("You have entered the ROBOT COMMAND TERMINAL. Control the robot with the following commands - \n M = MOVE\n A = MOVE ARM\n C = COLLECT CUBE\n S = SCORE")

while continueProgram == True:
	command = input("> ")

	while command != "M" and command != "A" and command != "C" and command != "S":
		print("That is not a valid command. Please try again.")
		command = input("> ")

	if command == "M":
		print("Enter number of spaces to move.")
		numberOfSpaces = input(">> ")

		robot.move(int(numberOfSpaces))

	elif command == "A":
		print("Enter number of inches to move the arm up or down. To move down, enter a negative number.")
		armNumberOfInches = input(">> ")

		robot.arm(int(armNumberOfInches))

	elif command == "C":
		robot.collectCube()

	elif command == "S":
		robot.scoreCube()

